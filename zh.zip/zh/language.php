<?php

	// IMPORTANT:
	// ==========
	// When translating, only translate the strings that are
	// TO THE RIGHT OF the equal sign (=).
	//
	// Do NOT translate the strings between square brackets ([])
	//
	// Also, leave the text between < and > untranslated.
	//
	// =====================================================
	// PLEASE NOTE:
	// ============
	// When a new version of AppGini is released, new strings
	// might be added to the "defaultLang.php" file. To translate
	// them, simply copy them to this file ("language.php") and 
	// translate them here. Do NOT translate them directly in 
	// the "defaultLang.php" file.
	// =====================================================
		


	// datalist.php
	$Translation['powered by'] = "驅動軟件";
	$Translation['quick search'] = "快速搜索";
	$Translation['records x to y of z'] = "從 <FirstRecord> 到 <LastRecord> 共 <RecordCount> 記錄";
	$Translation['filters'] = "篩選";
	$Translation['filter'] = "篩選";
	$Translation['filtered field'] = "篩選字段";
	$Translation['comparison operator'] = "比較運算符";
	$Translation['comparison value'] = "比較值";      
	$Translation['and'] = "與";
	$Translation['or'] = "或";
	$Translation['equal to'] = "等于";
	$Translation['not equal to'] = "不等于";
	$Translation['greater than'] = "大于";
	$Translation['greater than or equal to'] = "大于或等于";
	$Translation['less than'] = "小于";
	$Translation['less than or equal to'] = "小于或等于";
	$Translation['like'] = "類似";
	$Translation['not like'] = "不類似";
	$Translation['is empty'] = "是空的";
	$Translation['is not empty'] = "不是空的";
	$Translation['apply filters'] = "運用篩選";
	$Translation['save filters'] = "保存和運用篩選";
	$Translation['saved filters title'] = "用于篩選的HTML代碼";
	$Translation['saved filters instructions'] = "複制下面的代碼並粘貼到壹個HTML文本文件以保存您剛才定義的篩選使您可以在今後任何時候再使用而無需重新定義。您可以保存這段代碼在您的計算機上或在任何服務器上以便訪問此表覽。";
	$Translation['hide code'] = "隱藏此代碼";
	$Translation['printer friendly view'] = "適用打印機的視圖";
	$Translation['save as csv'] = "作爲CVS的文檔下載（用逗號分隔的值）";
	$Translation['edit filters'] = "編輯篩選";
	$Translation['clear filters'] = "清除篩選";
	$Translation['order by'] = '排序';
	$Translation['go to page'] = '翻到頁數:';
	$Translation['none'] = '無結果';
	$Translation['Select all records'] = '選擇所有記錄';
	$Translation['With selected records'] = '被選中的記錄';
	$Translation['Print Preview Detail View'] = '打印預覽詳細視圖';
	$Translation['Print Preview Table View'] = '打印預覽表格視圖';
	$Translation['Print'] = '打印';
	$Translation['Cancel Printing'] = '取消打印';
	$Translation['Cancel Selection'] = '取消選擇';
	$Translation['Maximum records allowed to enable this feature is'] = '能啓用此功能的最多記錄數是：';
	$Translation['No matches found!'] = '沒有找到匹配!';
	$Translation['Start typing to get suggestions'] = '開始鍵入以得到建議.';

	// _dml.php
	$Translation['are you sure?'] = '您確定要刪除此記錄?';
	$Translation['add new record'] = '添加新記錄';
	$Translation['update record'] = '更新記錄';
	$Translation['delete record'] = '刪除記錄';
	$Translation['deselect record'] = '取消選擇的記錄 ';
	$Translation["couldn't delete"] = '不能刪除記錄，因爲在表 [<TableName>] 中存在相關記錄<RelatedRecords> ,';
	$Translation['confirm delete'] = '該記錄在表[<TableName>]中有相關記錄 <RelatedRecords> . 您是否仍要刪除它? <Delete> &nbsp; <Cancel>';
	$Translation['yes'] = '是';
	$Translation['no'] = '否';
	$Translation['pkfield empty'] = ' 字段是主鍵字段不能是空的.';
	$Translation['upload image'] = '上傳新文件 ';
	$Translation['select image'] = '選擇壹個圖像 ';
	$Translation['remove image'] = '刪除文件';
	$Translation['month names'] = '1月,2月,3月,4月,5月,6月,7月,8月,9月,10月,11月,12月';
	$Translation['field not null'] = '您不能留該字段空白.';
	$Translation['*'] = '*';
	$Translation['today'] = '今天';
	$Translation['Hold CTRL key to select multiple items from the above list.'] = '按住CTRL鍵從上面的列表中選擇多個條目，.';
	$Translation['Save New'] = '保存爲新建';
	$Translation['Save As Copy'] = '保存爲複制';
	$Translation['Deselect'] = '取消';
	$Translation['Add New'] = '添加新建';
	$Translation['Delete'] = '刪除';
	$Translation['Cancel'] = '取消';
	$Translation['Print Preview'] = '打印預覽';
	$Translation['Print'] = '打印';
	$Translation['Save Changes'] = '保存修改';
	$Translation['CSV'] = '保存爲 CSV';
	$Translation['Reset Filters'] = '顯示全部';
	$Translation['Find It'] = '尋找';
	$Translation['Previous'] = '上壹個';
	$Translation['Next'] = '下壹個';
	$Translation['Back'] = '返回';

	// lib.php	
	$Translation['select a table'] = "跳轉到 ...";
	$Translation['homepage'] = "主頁";
	$Translation['error:'] = "出錯:";
	$Translation['sql error:'] = "SQL 錯誤:";
	$Translation['query:'] = "查詢:";
	$Translation['< back'] = "&lt; 返回";
	$Translation["if you haven't set up"] = "如果您還沒有建立數據庫，您可以通過點擊 <a href='setup.php'>這裏</a>.";
	$Translation['file too large']="錯誤：您上傳的文件超過了允許的最大尺寸 <MaxSize> KB";
	$Translation['invalid file type']="錯誤：此類型的文件是不允許的. 只有<FileTypes>的文件可以上傳";

	// setup.php
	$Translation['goto start page'] = "回到起始頁";
	$Translation['no db connection'] = "不能建立壹個數據庫連接.";
	$Translation['no db name'] = "在本服務器上無法訪問指定的數據庫 '<DBName>' .";
	$Translation['provide connection data'] = "請提供下列數據以連接數據庫:";
	$Translation['mysql server'] = "MySQL 服務器 (host)";
	$Translation['mysql username'] = "MySQL 用戶名";
	$Translation['mysql password'] = "MySQL 密碼";
	$Translation['mysql db'] = "數據庫名字";
	$Translation['connect'] = "連接";
	$Translation['couldnt save config'] = "無法保存連接數據到'config.php'.<br />請確保文件夾:<br />'".dirname(__FILE__)."'<br />是可寫的 (chmod 775 or chmod 777).";
	$Translation['setup performed'] = "安裝程序已完成";
	$Translation['delete md5'] = "如果您想強制再運行安裝程序，您必須從這個文件夾內先刪除文件 'setup.md5'.";
	$Translation['table exists'] = "表 <b><TableName></b> 已存在, 內有 <NumRecords> 記錄.";
	$Translation['failed'] = "失敗";
	$Translation['ok'] = "完成";
	$Translation['mysql said'] = "MySQL 說:";
	$Translation['table uptodate'] = "表是最新的.";
	$Translation['couldnt count'] = "無法計數表<b><TableName></b>的記錄";
	$Translation['creating table'] = "正在創建表 <b><TableName></b> ... ";

	// separateDVTV.php
	$Translation['please wait'] = "請稍候";

	// _view.php
	$Translation['tableAccessDenied']="對不起！您沒有權限訪問此表。請與管理員聯系.";

	// incCommon.php
	$Translation['not signed in']="您沒有登錄";
	$Translation['sign in']="登錄";
	$Translation['signed as']="登錄爲";
	$Translation['sign out']="退出";
	$Translation['admin setup needed']="尚未安裝管理員。請登錄到 <a href=admin/>管理員控制面板</a> 執行安裝程序.";
	$Translation['db setup needed']="尚未安裝程序. 請先登錄到 <a href=setup.php>安裝頁面</a> .";
	$Translation['new record saved']="新的記錄已成功保存.";
	$Translation['record updated']="更改已成功保存.";

	// index.php
	$Translation['admin area']="管理區";
	$Translation['login failed']="您以前的登錄嘗試失敗。再試試.";
	$Translation['sign in here']="在此登錄";
	$Translation['remember me']="記住我";
	$Translation['username']="用戶名";
	$Translation['password']="密碼";
	$Translation['go to signup']="沒有用戶名? <br />&nbsp; <a href=membership_signup.php>在此注冊</a>";
	$Translation['forgot password']="忘了您的密碼? <a href=membership_passwordReset.php>點擊這裏</a>";
	$Translation['browse as guest']="<a href=index.php>作爲來訪者繼續浏覽</a>";
	$Translation['no table access']="您沒有足夠的權限訪問這裏的任何網頁。請先登錄.";
	$Translation['signup']="注冊";

	// checkMemberID.php
	$Translation['user already exists']="用戶名 '<MemberID>' 已經存在。嘗試另壹個用戶名.";
	$Translation['user available']="用戶名 '<MemberID>' 可用的，您可以用它.";
	$Translation['empty user']="請先鍵入用戶名框，然後點擊 '檢查是否可用'.";

	// membership_thankyou.php
	$Translation['thanks']="謝謝您注冊!";
	$Translation['sign in no approval']="如果您選擇了壹個不需要管理員批准的組, 您現在就可以在<a href=index.php?signIn=1>這裏</a>登錄.";
	$Translation['sign in wait approval']="如果您選擇了壹個需要管理員批准的組，，請等待壹個電子郵件確認您的批准.";

	// membership_signup.php
	$Translation['username empty']="必須提供用戶名。請返回並鍵入用戶名";
	$Translation['password invalid']="您必須提供至少4個字符，不含空格的密碼。請返回並鍵入有效的密碼。";
	$Translation['password no match']="密碼不匹配。請返回並改正密碼";
	$Translation['username exists']="用戶名已經存在。請返回選擇壹個不同的用戶名.";
	$Translation['email invalid']="無效的電子郵件地址。請返回並改正您的電子郵件地址.";
	$Translation['group invalid']="無效的組。請返回並改正組的選擇.";
	$Translation['sign up here']="在這裏注冊!";
	$Translation['registered? sign in']="已注冊過? <a href=index.php?signIn=1>在這裏登錄</a>.";
	$Translation['sign up disabled']="對不起！管理員暫時禁用注冊。稍後再試.";
	$Translation['check availability']="看看這個用戶名是否可用";
	$Translation['confirm password']="確認密碼";
	$Translation['email']="電子郵件地址";
	$Translation['group']=" 組";
	$Translation['groups *']="如果您選擇注冊壹個標有星號（*）的組，您將無法登錄直到管理員批准您。您被批准後會收到壹封電子郵件時.";
	$Translation['sign up']="注冊";

	// membership_passwordReset.php
	$Translation['password reset']="密碼重置頁面";
	$Translation['password reset details']="在下面輸入您的用戶名或電子郵件地址。然後我們將發送壹個特殊鏈接到您的電子郵件。當您點擊鏈接，您會被要求輸入新的密碼.";
	$Translation['password reset subject']="密碼重置說明";
	$Translation['password reset message']="親愛的會員, \n 如果您曾經要求重設/更改您的密碼，請點擊此鏈接: \n <ResetLink> \n\n 如果您沒有要求密碼重設/更改，請忽略此信息. \n\n 謹此問候.";
	$Translation['password reset ready']="壹封有密碼重置指令的郵件已發送到您注冊的電子郵件地址。請保持這個浏覽器窗口並按照電子郵件的指示.<br /><br />如果您在5分鍾內沒有收到這封郵件，嘗試再重置密碼，並確保您輸入正確的用戶名或電子郵件地址.";
	$Translation['password reset invalid']="無效的用戶名或密碼. <a href=membership_passwordReset.php>再試壹次</a>, 或者<a href=index.php>回到主頁</a>.";
	$Translation['password change']="密碼更改頁面";
	$Translation['new password']="新密碼";
	$Translation['password reset done']="您的密碼已經更改成功。您可以 <a href=index.php?signOut=1>在這裏用新密碼登錄</a>.";

    $Translation['Loading ...']='加載中 ...';
    $Translation['No records found']='沒有找到記錄';
    $Translation['You can add children records after saving the main record first']='您在保存主記錄後可以添加子記錄';

    $Translation['ascending'] = '升序';
    $Translation['descending'] = '降序';
    $Translation['then by'] = '然後按照';

	// membership_profile
	$Translation['Legend'] = '圖例';
	$Translation['Table'] = '表';
	$Translation['Edit'] = '編輯';
	$Translation['View'] = '察看';
	$Translation['Only your own records'] = '只有您自己的記錄';
	$Translation['All records owned by your group'] = '您的組所擁有的全部記錄';
	$Translation['All records'] = '全部記錄';
	$Translation['Not allowed'] = '不允許';
	$Translation['Your info'] = '您的信息';
	$Translation['Hello user'] = '您好 %s!';
	$Translation['Your access permissions'] = '您的訪問權限';
	$Translation['Update profile'] = '更新個人資料';
	$Translation['Update password'] = '更新密碼';
	$Translation['Change your password'] = '更改您的密碼';
	$Translation['Old password'] = '舊密碼';
	$Translation['Password strength: weak'] = '密碼保密度：弱';
	$Translation['Password strength: good'] = '密碼保密度：好';
	$Translation['Password strength: strong'] = '密碼保密度：強';
	$Translation['Wrong password'] = '錯誤密碼';
	$Translation['Your profile was updated successfully'] = '您個人資料更新成功';
	$Translation['Your password was changed successfully'] = '您的密碼已經更改成功';
	$Translation['Your IP address'] = '您的IP地址';
?>
